// USB-A host Away from PC

#include <stdlib.h>
#include <string.h>
#include <assert.h>
#include <inttypes.h>
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "freertos/queue.h"
#include "esp_err.h"
#include "esp_log.h"
#include "driver/gpio.h"
#include "driver/uart.h"
#include "usb/usb_host.h"
#include "usb/msc_host.h" // raw read/write + device info
#include "mscp_proto.h"

#define TAG "msc_host_proxy"
#define UART_PORT UART_NUM_1
#define UART_TX_PIN GPIO_NUM_17 // ESP-A TX -> ESP-B RX
#define UART_RX_PIN GPIO_NUM_16 // ESP-A RX <- ESP-B TX
#define UART_BAUD 921600
#define APP_QUIT_PIN GPIO_NUM_0 // optional BOOT button
#define IO_BUF_MAX (64 * 1024)
// ========================

// HID


static inline void uart_send_all(const void *p, size_t n)
{
    const uint8_t *c = (const uint8_t *)p;
    while (n)
    {
        int w = uart_write_bytes(UART_PORT, (const char *)c, n);
        if (w > 0)
        {
            c += w;
            n -= w;
        }
    }
}

static inline bool uart_read_exact(void *p, size_t n, TickType_t to_ticks)
{
    uint8_t *c = (uint8_t *)p;
    size_t got = 0;
    while (got < n)
    {
        int r = uart_read_bytes(UART_PORT, c + got, n - got, to_ticks);
        if (r <= 0)
            return false;
        got += r;
    }
    return true;
}

static inline uint32_t crc32_u(uint32_t crc, const void *data, size_t len)
{
    const uint8_t *p = (const uint8_t *)data;
    crc = ~crc;
    while (len--)
    {
        crc ^= *p++;
        for (int k = 0; k < 8; k++)
            crc = (crc >> 1) ^ (0xEDB88320u & -(int)(crc & 1));
    }
    return ~crc;
}

static inline uint32_t mscp_crc32_calc(const void *hdr_no_crc, size_t hdr_len,
                                       const void *payload, size_t pay_len)
{
    uint32_t c = 0;
    c = crc32_u(c, hdr_no_crc, hdr_len);
    if (payload && pay_len)
        c = crc32_u(c, payload, pay_len);
    return c;
}

// ---- Packet I/O ----
static inline void mscp_send_pkt(uint8_t opcode, uint32_t tag, uint32_t lba, uint16_t blocks,
                                 const void *payload, uint32_t len)
{
    mscp_hdr_t h = {
        .magic = MSCP_MAGIC, .ver = MSCP_VER, .opcode = opcode, .rsvd = 0, .tag = tag, .lba = lba, .blocks = blocks, .data_len = len};
    h.crc32 = mscp_crc32_calc(&h, sizeof(h) - 4, payload, len);

    ESP_LOGI(TAG, "UART<- send opcode=0x%02X tag=%" PRIu32 " lba=%" PRIu32 " blocks=%u len=%" PRIu32,
             opcode, tag, lba, blocks, len);

    uart_send_all(&h, sizeof(h));
    if (len && payload)
        uart_send_all(payload, len);
}

static inline bool mscp_recv_hdr(mscp_hdr_t *h, TickType_t to_ticks)
{
    if (!uart_read_exact(h, sizeof(*h), to_ticks))
        return false;
    bool ok = (h->magic == MSCP_MAGIC && h->ver == MSCP_VER);
    if (!ok)
        ESP_LOGW(TAG, "UART-> bad header");
    else
        ESP_LOGI(TAG, "UART-> opcode=0x%02X tag=%" PRIu32 " lba=%" PRIu32 " blocks=%u len=%" PRIu32,
                 h->opcode, h->tag, h->lba, h->blocks, h->data_len);
    return ok;
}

static inline bool mscp_recv_payload_check(const mscp_hdr_t *h, void *buf, size_t cap, TickType_t to_ticks)
{
    if (h->data_len == 0)
    {
        uint32_t c = mscp_crc32_calc(h, sizeof(*h) - 4, NULL, 0);
        return (c == h->crc32);
    }
    if (h->data_len > cap)
        return false;
    if (!uart_read_exact(buf, h->data_len, to_ticks))
        return false;
    uint32_t c = mscp_crc32_calc(h, sizeof(*h) - 4, buf, h->data_len);
    return (c == h->crc32);
}

// ---- USB/MSC state ----
static msc_host_device_handle_t g_dev = NULL;
static uint32_t g_blk_sz = 512;
static uint64_t g_blk_cnt = 0;

// ---- App queue/events ----
typedef struct
{
    enum
    {
        APP_QUIT,
        APP_DEVICE_CONNECTED,
        APP_DEVICE_DISCONNECTED
    } id;
    union
    {
        uint8_t new_dev_address;
        msc_host_device_handle_t device_handle;
    } data;
} app_message_t;

static QueueHandle_t app_queue = NULL;

static void msc_event_cb(const msc_host_event_t *event, void *arg)
{
    (void)arg;
    if (event->event == MSC_DEVICE_CONNECTED)
    {
        ESP_LOGI(TAG, "MSC CONNECTED (addr=%u)", event->device.address);
        app_message_t m = {.id = APP_DEVICE_CONNECTED};
        m.data.new_dev_address = event->device.address;
        xQueueSend(app_queue, &m, portMAX_DELAY);
    }
    else if (event->event == MSC_DEVICE_DISCONNECTED)
    {
        ESP_LOGI(TAG, "MSC DISCONNECTED");
        app_message_t m = {.id = APP_DEVICE_DISCONNECTED};
        m.data.device_handle = event->device.handle;
        xQueueSend(app_queue, &m, portMAX_DELAY);
    }
}

// ---- USB host task ----
static void usb_task(void *arg)
{
    const usb_host_config_t host_config = {.intr_flags = ESP_INTR_FLAG_LEVEL1};
    ESP_ERROR_CHECK(usb_host_install(&host_config));

    const msc_host_driver_config_t msc_cfg = {
        .create_backround_task = true,
        .task_priority = 5,
        .stack_size = 4096,
        .callback = msc_event_cb,
    };
    ESP_ERROR_CHECK(msc_host_install(&msc_cfg));

    // Pump events
    bool has_clients = true;
    while (1)
    {
        uint32_t event_flags;
        usb_host_lib_handle_events(portMAX_DELAY, &event_flags);
        if (event_flags & USB_HOST_LIB_EVENT_FLAGS_NO_CLIENTS)
        {
            has_clients = false;
            if (usb_host_device_free_all() == ESP_OK)
                break;
        }
        if ((event_flags & USB_HOST_LIB_EVENT_FLAGS_ALL_FREE) && !has_clients)
            break;
    }

    vTaskDelay(10);
    ESP_LOGI(TAG, "USB host uninstall");
    ESP_ERROR_CHECK(usb_host_uninstall());
    vTaskDelete(NULL);
}

// ---- UART <-> MSC worker ----
static TaskHandle_t s_mscp_task = NULL;

static void mscp_worker_task(void *arg)
{
    uint8_t *io_buf = malloc(IO_BUF_MAX);
    ESP_LOGI(TAG, "MSCP worker started buf=%p", io_buf);

    while (1)
    {
        mscp_hdr_t h;
        if (!mscp_recv_hdr(&h, portMAX_DELAY))
            continue;

        switch (h.opcode)
        {

        case MSCP_INFO_REQ:
        {
            mscp_info_t info = {.block_size = g_blk_sz, .block_count = g_blk_cnt};
            ESP_LOGI(TAG, "INFO_REQ -> size=%" PRIu32 ", count=%" PRIu64, g_blk_sz, g_blk_cnt);
            mscp_send_pkt(MSCP_INFO_RSP, h.tag, 0, 0, &info, sizeof(info));
            break;
        }

        case MSCP_READ_REQ:
        {
            if (!g_dev)
            {
                uint32_t code = 1;
                mscp_send_pkt(MSCP_STATUS, h.tag, 0, 0, &code, sizeof(code));
                break;
            }
            size_t bytes = (size_t)h.blocks * g_blk_sz;
            if (!io_buf || bytes > IO_BUF_MAX)
            {
                uint32_t code = 2;
                mscp_send_pkt(MSCP_STATUS, h.tag, 0, 0, &code, sizeof(code));
                break;
            }
            ESP_LOGI(TAG, "READ lba=%" PRIu32 " blocks=%u (%u bytes)", h.lba, h.blocks, (unsigned)bytes);
            esp_err_t err = msc_host_read_sector(g_dev, h.lba, io_buf, bytes); // (deprecated) OK here
            if (err == ESP_OK)
            {
                mscp_send_pkt(MSCP_READ_RSP, h.tag, h.lba, h.blocks, io_buf, (uint32_t)bytes);
            }
            else
            {
                ESP_LOGE(TAG, "msc_host_read_sector err=%d", (int)err);
                uint32_t code = (uint32_t)err;
                mscp_send_pkt(MSCP_STATUS, h.tag, 0, 0, &code, sizeof(code));
            }
            break;
        }

        case MSCP_WRITE_REQ:
        {
            if (!g_dev)
            {
                uint32_t code = 1;
                mscp_send_pkt(MSCP_STATUS, h.tag, 0, 0, &code, sizeof(code));
                break;
            }
            size_t bytes = (size_t)h.blocks * g_blk_sz;
            if (!io_buf || bytes > IO_BUF_MAX || h.data_len != bytes)
            {
                uint32_t code = 3; // size mismatch
                if (io_buf && h.data_len <= IO_BUF_MAX)
                    (void)mscp_recv_payload_check(&h, io_buf, h.data_len, pdMS_TO_TICKS(1000));
                mscp_send_pkt(MSCP_STATUS, h.tag, 0, 0, &code, sizeof(code));
                break;
            }
            if (!mscp_recv_payload_check(&h, io_buf, bytes, pdMS_TO_TICKS(3000)))
            {
                uint32_t code = 4; // CRC/timeout
                mscp_send_pkt(MSCP_STATUS, h.tag, 0, 0, &code, sizeof(code));
                break;
            }
            ESP_LOGI(TAG, "WRITE lba=%" PRIu32 " blocks=%u (%u bytes)", h.lba, h.blocks, (unsigned)bytes);
            esp_err_t err = msc_host_write_sector(g_dev, h.lba, io_buf, bytes); // (deprecated) OK here
            if (err == ESP_OK)
            {
                mscp_send_pkt(MSCP_WRITE_RSP, h.tag, h.lba, h.blocks, NULL, 0);
            }
            else
            {
                ESP_LOGE(TAG, "msc_host_write_sector err=%d", (int)err);
                uint32_t code = (uint32_t)err;
                mscp_send_pkt(MSCP_STATUS, h.tag, 0, 0, &code, sizeof(code));
            }
            break;
        }

        default:
        {
            uint32_t code = 0xFFFF0000u | h.opcode;
            mscp_send_pkt(MSCP_STATUS, h.tag, 0, 0, &code, sizeof(code));
            break;
        }
        }
    }
}

// ---- UART Initiation ----
static void uart_init(void)
{
    const uart_config_t cfg = {
        .baud_rate = UART_BAUD,
        .data_bits = UART_DATA_8_BITS,
        .parity = UART_PARITY_DISABLE,
        .stop_bits = UART_STOP_BITS_1,
        .flow_ctrl = UART_HW_FLOWCTRL_DISABLE};
    ESP_ERROR_CHECK(uart_param_config(UART_PORT, &cfg));
    ESP_ERROR_CHECK(uart_set_pin(UART_PORT, UART_TX_PIN, UART_RX_PIN,
                                 UART_PIN_NO_CHANGE, UART_PIN_NO_CHANGE));
    ESP_ERROR_CHECK(uart_driver_install(UART_PORT, 4 * 1024, 0, 0, NULL, 0));
    ESP_LOGI(TAG, "UART init @ %d baud", UART_BAUD);
}

// ---- On-connect boot map probe (debug) ----
static void probe_bootmap(msc_host_device_handle_t dev)
{
    uint8_t boot[512];

    if (msc_host_read_sector(dev, 0, boot, 512) != ESP_OK)
    {
        ESP_LOGW(TAG, "Probe: read LBA0 failed");
        return;
    }

    ESP_LOGI(TAG, "A: LBA0 bytes[0..15]: %02X %02X %02X %02X  %02X %02X %02X %02X  %02X %02X %02X %02X  %02X %02X %02X %02X",
             boot[0], boot[1], boot[2], boot[3], boot[4], boot[5], boot[6], boot[7],
             boot[8], boot[9], boot[10], boot[11], boot[12], boot[13], boot[14], boot[15]);
    ESP_LOGI(TAG, "A: MBR signature @510..511: %02X %02X", boot[510], boot[511]);

    // Partition #0 entry
    uint8_t p0_type = boot[446 + 4];
    uint32_t p0_lba = *(uint32_t *)&boot[446 + 8];
    uint32_t p0_len = *(uint32_t *)&boot[446 + 12];
    ESP_LOGI(TAG, "A: MBR P0: type=0x%02X start=%" PRIu32 " len=%" PRIu32, p0_type, p0_lba, p0_len);

    if (p0_lba && p0_lba < g_blk_cnt)
    {
        if (msc_host_read_sector(dev, p0_lba, boot, 512) == ESP_OK)
        {
            ESP_LOGI(TAG, "A: P0 boot @LBA%" PRIu32 " first16: "
                          "%02X %02X %02X %02X  %02X %02X %02X %02X  %02X %02X %02X %02X  %02X %02X %02X %02X",
                     p0_lba,
                     boot[0], boot[1], boot[2], boot[3], boot[4], boot[5], boot[6], boot[7],
                     boot[8], boot[9], boot[10], boot[11], boot[12], boot[13], boot[14], boot[15]);

            // quick signature peek
            const char *sig = NULL;
            if (memmem(boot, 90, "NTFS    ", 8))
                sig = "NTFS";
            else if (memmem(boot, 90, "EXFAT   ", 8))
                sig = "exFAT";
            else if (memmem(boot, 90, "FAT32   ", 8) || memmem(boot, 90, "MSDOS5.0", 8))
                sig = "FAT";
            ESP_LOGI(TAG, "A: P0 filesystem: %s", sig ? sig : "(unknown)");
        }
    }
}

// install device + start worker
static esp_err_t allocate_new_msc_device(uint8_t usb_addr, int *out_slot_dummy)
{
    (void)out_slot_dummy; // not used now

    msc_host_device_handle_t dev;
    esp_err_t err = msc_host_install_device(usb_addr, &dev);
    if (err != ESP_OK)
    {
        ESP_LOGE(TAG, "msc_host_install_device failed: %s", esp_err_to_name(err));
        return err;
    }

    // Save as active device
    g_dev = dev;

    // Get capacity
    msc_host_device_info_t info;
    ESP_ERROR_CHECK(msc_host_get_device_info(dev, &info));
    g_blk_sz = info.sector_size;
    g_blk_cnt = info.sector_count;

    ESP_LOGI(TAG, "Host proxy ready: block_size=%" PRIu32 ", block_count=%" PRIu64,
             g_blk_sz, g_blk_cnt);

    // One-time on-connect probe to understand layout
    probe_bootmap(dev);

    // Start UART worker once
    if (s_mscp_task == NULL)
    {
        xTaskCreate(mscp_worker_task, "mscp_uart", 4096, NULL, 5, &s_mscp_task);
    }
    return ESP_OK;
}

// ---- app_main ----
void app_main(void)
{
    uart_init();

    app_queue = xQueueCreate(5, sizeof(app_message_t));
    assert(app_queue);

    BaseType_t ok = xTaskCreate(usb_task, "usb_task", 4096, NULL, 2, NULL);
    assert(ok);

    ESP_LOGI(TAG, "Waiting for USB flash drive..");

    while (1)
    {
        app_message_t msg;
        xQueueReceive(app_queue, &msg, portMAX_DELAY);
        if (msg.id == APP_DEVICE_CONNECTED)
        {
            (void)allocate_new_msc_device(msg.data.new_dev_address, NULL);
        }
        else if (msg.id == APP_DEVICE_DISCONNECTED)
        {
            g_dev = NULL; // stop serving
            ESP_LOGI(TAG, "Device removed");
        }
        else if (msg.id == APP_QUIT)
        {
            break;
        }
    }
}
