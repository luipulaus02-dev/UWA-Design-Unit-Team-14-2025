#pragma once
#include <stdint.h>

// ---- Protocol constants ----
#define MSCP_MAGIC 0x4D534350u /* 'M''S''C''P' */
#define MSCP_VER   1

// Opcodes
#define MSCP_INFO_REQ   0x01
#define MSCP_INFO_RSP   0x81
#define MSCP_READ_REQ   0x02
#define MSCP_READ_RSP   0x82
#define MSCP_WRITE_REQ  0x03
#define MSCP_WRITE_RSP  0x83
#define MSCP_STATUS     0xFF

// ---- Packet formats ----
typedef struct __attribute__((packed)) {
    uint32_t magic;
    uint8_t  ver;
    uint8_t  opcode;
    uint16_t rsvd;      // keep 0
    uint32_t tag;
    uint32_t lba;
    uint16_t blocks;
    uint32_t data_len;
    uint32_t crc32;     // CRC of all fields above + payload (if any)
} mscp_hdr_t;

typedef struct __attribute__((packed)) {
    uint32_t block_size;   // bytes (must be 512)
    uint64_t block_count;  // total LBAs
} mscp_info_t;
