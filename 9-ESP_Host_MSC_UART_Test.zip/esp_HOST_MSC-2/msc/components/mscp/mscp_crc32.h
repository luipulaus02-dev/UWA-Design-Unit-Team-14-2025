#pragma once
#include <stddef.h>
#include <stdint.h>
static inline uint32_t mscp_crc32_update(uint32_t crc, const void *data, size_t len) {
  const uint8_t *p = (const uint8_t*)data;
  crc = ~crc;
  while (len--) {
    crc ^= *p++;
    for (int k = 0; k < 8; k++)
      crc = (crc >> 1) ^ (0xEDB88320u & (-(int32_t)(crc & 1)));
  }
  return ~crc;
}
static inline uint32_t mscp_crc32_calc(const void *hdr_except_crc, size_t hdr_len, const void *payload, size_t pay_len) {
  uint32_t crc = 0;
  crc = mscp_crc32_update(crc, hdr_except_crc, hdr_len);
  if (payload && pay_len) crc = mscp_crc32_update(crc, payload, pay_len);
  return crc;
}
