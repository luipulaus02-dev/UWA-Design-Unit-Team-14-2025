#pragma once
#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

#define MSCP_MAGIC  0xC3A5
#define MSCP_VER    1

// Common header (both directions)
typedef struct __attribute__((packed)) {
  uint16_t magic;      // 0xC3A5
  uint8_t  ver;        // 1
  uint8_t  opcode;     // see enum below
  uint32_t tag;        // echo back for matching
  uint32_t lba;        // logical block address
  uint16_t blocks;     // number of 512B blocks
  uint32_t data_len;   // payload length (bytes) following the header
  uint32_t rsvd;
  uint32_t crc32;      // CRC32 of header(except crc)+payload
} mscp_hdr_t;

enum {
  MSCP_INFO_REQ   = 0x01, // B->A ask capacity & block size
  MSCP_INFO_RSP   = 0x02, // A->B reply {block_size, block_count}
  MSCP_READ_REQ   = 0x10, // B->A read LBA..blocks
  MSCP_READ_RSP   = 0x11, // A->B data payload (blocks*blk_size)
  MSCP_WRITE_REQ  = 0x12, // B->A write with payload
  MSCP_WRITE_RSP  = 0x13, // A->B status only
  MSCP_STATUS     = 0x20, // optional async status/errors
};

typedef struct __attribute__((packed)) {
  uint32_t block_size;   // usually 512
    uint64_t block_count;  // capacity in blocks
} mscp_info_t;

// Optional sanity check (GCC/Clang). If it fails, struct isn't packed.
_Static_assert(sizeof(mscp_hdr_t) == 26, "mscp_hdr_t must be packed to 26 bytes");

#ifdef __cplusplus
}
#endif
